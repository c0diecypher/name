import React from "react";
import "./main.css";

function SizeInfo() {
  return (
    <div>
      <p className="Size">Размер US </p>
      <p className="Size">Размерная сетка </p>
    </div>
  );
}

export default SizeInfo;
