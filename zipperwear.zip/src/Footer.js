import "./main.css";
import React from "react";

function Footer() {
  return (
    <footer>
      <p className="version">App version 1.0 </p>
    </footer>
  );
}

export default Footer;
