import "./styles.css";

export default [
  {
    id: "1",
    name: "adidas Ozweego",
    img: "adidas-ozweego-black.jpg",
    description: "Everyone's favorite cat who loves to hate",
    category: "Adidas",
    price: "9 999"
  },
  {
    id: "2",
    name: "Nike AirForce",
    img: "nike-airforce-midnightNavy.jpg",
    category: "Nike",
    description:
      "He bends! He stretches! He even ties in knots, but always returns to his original shape!",
    price: "5 300"
  },
  {
    id: "3",
    name: "Vans OldSkool",
    img: "Vans-oldSkool.jpg",
    category: "Vans",
    description:
      "It's a race, it's a chase, hurry up and feed their face! Who will win? No one knows! Feed the hungry hip-ip-pos!",
    price: "8 590"
  },
  {
    id: "4",
    name: "Converse Chuck Taylor ",
    img: "Converse-ChuckTaylorAsCore.jpg",
    category: "Converse",
    description: "You'll get caught up in the crossfire!",
    price: "9 899"
  },
  {
    id: "5",
    name: "PUMA RS-X",
    img: "Puma-Rs-X.jpg",
    category: "Puma",
    description:
      "It's a race, it's a chase, hurry up and feed their face! Who will win? No one knows! Feed the hungry hip-ip-pos!",
    price: "15 999"
  },
  {
    id: "6",
    name: "Reebok Club C 85",
    img: "Reebok-Club-C-85.jpg",
    description:
      "It's a race, it's a chase, hurry up and feed their face! Who will win? No one knows! Feed the hungry hip-ip-pos!",
    price: "13 499"
  }
];
